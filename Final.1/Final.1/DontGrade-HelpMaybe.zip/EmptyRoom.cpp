/******************************************************************************
* Tucker Lavell
* CS162 Fall 2017
* Final Project
* EmptyRoom.cpp
******************************************************************************/
#include "EmptyRoom.hpp"
#include "Space.hpp"

EmptyRoom::EmptyRoom() {
	
}

EmptyRoom::~EmptyRoom() {

}

void EmptyRoom::printRoom() {

}