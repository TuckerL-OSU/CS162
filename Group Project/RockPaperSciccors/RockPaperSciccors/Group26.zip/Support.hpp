#include <iostream>
#include <string>
#include <limits>
#include <limits.h>
#include <locale>
using std::string;
using std::cout;
using std::cin;
using std::endl;
using std::getline;
using std::numeric_limits;
using std::streamsize;


int getValidIntegerInput(string, int, int);
string getStringInput();
char getCharInput();
int RNG(int, int);
